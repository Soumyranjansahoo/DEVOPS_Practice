#!/bin/sh
## 1) backup your pom
cp pom.xml pom.xml.bak

# 2) (edit) open the pom in vi/nano and paste the block above just before </project>
vi pom.xml
# (paste the block and save)

# 3) remove old cached plugin/artifacts so Maven downloads fresh compatible versions
rm -rf ~/.m2/repository/org/apache/maven/plugins/maven-war-plugin
rm -rf ~/.m2/repository/org/apache/maven/plugins/maven-compiler-plugin
rm -rf ~/.m2/repository/org/codehaus/plexus

# 4) force update and build
mvn -U clean package

